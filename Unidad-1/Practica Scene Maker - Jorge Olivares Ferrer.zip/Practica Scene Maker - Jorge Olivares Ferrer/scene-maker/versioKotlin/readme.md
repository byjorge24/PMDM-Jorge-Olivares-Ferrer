# Versió Kotlin de l'SceneMaker

En esta carpeta disposeu del plantejament de l'exercici SceneMaker amb Kotlin.
